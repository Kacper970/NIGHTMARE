# -*- coding: utf-8 -*-
"""
Created on Sat Feb  8 16:39:53 2025

@author: kacpe
"""

import wandb

wandb.login(key="0f742e527885c45716c4a90d8bdebd500e0be879")