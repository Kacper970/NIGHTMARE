# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 16:27:12 2025

@author: kacpe
"""

import os
#import io
import h5py
import json
import argparse
import numpy as np
import csv
#from PIL import Image
#from tqdm import tqdm
    
with open('Thesis Map/COMICS_TEXT_PLUS_ocr_file.csv', mode='r', newline='', encoding='utf-8') as file:
        
    reader = csv.DictReader(file)
        
    
    empty = 0
    nempty = 0
    
    for row in reader:
                           
        text = row['postprocessed_text']
        
        if text == '':
            empty+=1
        else:
            nempty+=1
            
print(empty)
print(nempty)